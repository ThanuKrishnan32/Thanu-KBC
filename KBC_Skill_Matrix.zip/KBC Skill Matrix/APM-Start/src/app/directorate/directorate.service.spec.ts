import { TestBed } from '@angular/core/testing';

import { DirectorateService } from './directorate.service';

describe('DirectorateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DirectorateService = TestBed.get(DirectorateService);
    expect(service).toBeTruthy();
  });
});
