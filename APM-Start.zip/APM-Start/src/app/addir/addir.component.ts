import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import {iadddirComponent} from 'db/interfaces'

@Component({
  selector: 'addir',
  templateUrl: './addir.component.html',
  styleUrls: ['./addir.component.css']
})
export class addirComponent implements OnInit {
  @ViewChild('adddirForm', {static: false}) public createDirForm: NgForm;
  adddirNew: iadddirComponent = {
    id: null,
    dirName: null,
    deptName: null,
    teamName: null
  } 
  constructor(private router: Router ) { }
  
    ngOnInit() {
    
  }

  saveDirectory() : void {
    console.log(this.adddirNew);
  }

  
  onBack(): void {
  this.router.navigate (['/directorate']);
}

    
}
