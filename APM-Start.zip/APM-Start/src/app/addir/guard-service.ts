import { CanDeactivate } from '@angular/router';
import { addirComponent} from './addir.component';
import { Injectable } from '@angular/core';

@Injectable()
export class GuardService implements CanDeactivate<addirComponent> {
    canDeactivate(component: addirComponent): boolean {
        if(component.createDirForm.dirty){
            return confirm('Are you sure you want to move to another page? This may discard your chnages');
        }
        else{
            return true;
        }    
    }
}