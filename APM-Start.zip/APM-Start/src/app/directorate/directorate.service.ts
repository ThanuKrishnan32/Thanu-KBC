import { Injectable } from '@angular/core';
import { IdirComponent } from 'db/interfaces';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DirectorateService {
  private dirUrl = 'http://localhost:1234/Directorates';

  constructor( private http: HttpClient) {

  }
  getDirectorate():Observable<IdirComponent[]>
  {
    return this.http.get<IdirComponent[]>(this.dirUrl).pipe(
      tap(data => console.log('All: ' + JSON.stringify(data))),
      catchError(this.handleError)
  );
}
private handleError(err: HttpErrorResponse){
  let errorMessage = '';
  if (err.error instanceof ErrorEvent) {
      errorMessage = 'An error occured: ${err.error.message}';
  }else {
      errorMessage = 'Server returned code: ${err.status}, error message is: ${err.message}';
  }
  console.error(errorMessage);
  return throwError(errorMessage);
}

}

