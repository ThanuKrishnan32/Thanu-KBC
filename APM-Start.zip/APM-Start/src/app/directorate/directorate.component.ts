import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProduct } from '../skills/product';
import { IdirComponent } from 'db/interfaces';
import { DirectorateService } from './directorate.service';

@Component({
  templateUrl: './directorate.component.html',
  styleUrls: ['./directorate.component.css']
})
export class DirectorateComponent implements OnInit {
  directorate: IdirComponent[]=[]; 
  constructor( private router: Router, private _directorateService: DirectorateService) { }

  ngOnInit() {
    this._directorateService.getDirectorate()
        .subscribe(data => this.directorate = data);
  }
onBack(): void {
  this.router.navigate (['/Welcome']);
}
}
