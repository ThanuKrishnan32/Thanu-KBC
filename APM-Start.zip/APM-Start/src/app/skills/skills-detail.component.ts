import { Component, OnInit } from '@angular/core';
import { IProduct } from './product';

@Component({
  templateUrl: './skills-detail.component.html',
  styleUrls: ['./skills-detail.component.css']
})
export class SkillsDetailComponent implements OnInit {

  pageTitle: string = 'Skill Detail';
  product: IProduct;

  constructor() { }

  ngOnInit() {
  }

}
