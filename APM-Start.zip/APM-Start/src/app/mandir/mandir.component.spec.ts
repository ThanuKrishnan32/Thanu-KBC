import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MandirComponent } from './mandir.component';

describe('MandirComponent', () => {
  let component: MandirComponent;
  let fixture: ComponentFixture<MandirComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MandirComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MandirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
