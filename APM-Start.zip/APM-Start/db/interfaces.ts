//Component interfaces
export interface iadddirComponent{
    id: number,
    dirName: string,
    deptName: string,
    teamName: string
}
export interface iadddeptComponent{

}
export interface IdirComponent{
    ID: number,
    CD: string,
    NAME: string,
    DESC: string,
    DEPT: string
    //DEPT?: [deptComponent]
}

export interface deptComponent{
    CD: string,
    NAME: string,
    DESC: string,
    SKILLSET: [],
    TEAM?: [teamComponent]
}

export interface teamComponent{
    CD: string,
    NAME: string,
    DESC: string,
    RESOURCE?: [resourceComponent]
}

export interface resourceComponent{
    ID: string,
    NAME: string,
    DESIGNATION: string,
    ROLE: string,
    STT_DT?: Date,
    SKILLSET: [],
    SKILL: []
}

//Calling interfaces
export interface dirCallitf{
    dir_cd: string,
    dir_name?: string,
    dir_desc?:  string
}

export interface deptCallitf{
    dir_cd: string,
    dept_cd: string,
    dept_name?: string,
    dept_desc?:  string
}

export interface teamCallitf{
    dir_cd: string,
    dept_cd: string,
    team_cd: string,
    team_name?: string,
    team_desc?:  string
}

export interface resourceCallItf{
    dir_cd: string,
    dept_cd: string,
    team_cd: string,
    res_id: string,
    res_name?: string,
    res_designation?: string,
    res_role?: string,
    res_stt_dt?: Date,
}