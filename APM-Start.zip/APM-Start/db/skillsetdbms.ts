
//Interfaces

import { dirComponent } from "../db/interfaces"
import { deptComponent } from "../db/interfaces"
import { teamComponent } from "../db/interfaces"
import { resourceComponent } from "../db/interfaces"

import { dirCallitf } from "../db/interfaces"
import { deptCallitf } from "../db/interfaces"
import { teamCallitf } from "../db/interfaces"
import { resourceCallItf } from "../db/interfaces"

//The DatabaseRequest Class

class dbrequest{
    
//temporary db data
    matrixdbstr: string;

    dirCpn: dirComponent;
    deptCpn: deptComponent;
    teamCpn: teamComponent;
    resCpn: resourceComponent;

    dirItf: dirCallitf;
    deptItf: deptCallitf;
    teamItf: teamCallitf;
    resItf: resourceCallItf;

    cddbstr: {};

    constructor(){

        this.matrixdbstr = "[]"

        console.log(this.matrixdbstr);
    }

//Entry point
    dbcall(cmd: string, itfData){

        console.log("dbcall invoked with " + cmd);

        return this.processcmd(cmd, itfData);

    }

//process directory component
    processcmd(cmd: string, itfData){

        let temparr = cmd.split(" ");
        let action = temparr[0];
        let cpn = temparr[1];
        
        switch(action){
            case "add":
                this.add(cpn, itfData);
                break;

            case "upd":
                this.update(cpn, itfData);
                break;

            case "sel":
                return this.select(cpn, itfData);
                break;

            case "del":
                this.delete(cpn, itfData);
                break;

            default:
                console.log("Invalid action!!");

        }

        console.log(this.matrixdbstr);
    }

    //process json
    
    add(cpn: string, itfData){

        let dbarr: [dirComponent];
        let deptArr: [deptComponent];
        let teamArr: [teamComponent];

        let dirIdx;
        let deptIdx;
        let teamIdx;

        dbarr = JSON.parse(this.matrixdbstr);

        switch(cpn){
            case "dir":

                this.dirItf = itfData;
                this.dirCpn = {
                    CD: this.dirItf.dir_cd,
                    NAME: this.dirItf.dir_name,
                    DESC: this.dirItf.dir_desc
                };

                dbarr.push(this.dirCpn);
                this.matrixdbstr = JSON.stringify(dbarr);
                break;

            case "dept":

                this.deptItf = itfData;
                this.deptCpn = {
                    CD: this.deptItf.dept_cd,
                    NAME: this.deptItf.dept_name,
                    DESC: this.deptItf.dept_desc,
                    SKILLSET: []
                };

                dirIdx = dbarr.findIndex(element => element.CD == this.deptItf.dir_cd);
                
                if(dirIdx < 0){
                    console.log("Root directive not found for add action!!");
                    break;
                }

                this.dirCpn = dbarr[dirIdx];
                
                if(this.dirCpn.DEPT){
                    this.dirCpn.DEPT.push(this.deptCpn);
                }else{
                    this.dirCpn.DEPT = [this.deptCpn];
                }

                dbarr[dirIdx] = this.dirCpn;
                
                this.matrixdbstr = JSON.stringify(dbarr);
                break;
            
            case "team":
                this.teamItf = itfData;
                this.teamCpn = {
                    CD: this.teamItf.team_cd,
                    NAME: this.teamItf.team_name,
                    DESC: this.teamItf.team_desc
                };

                dirIdx = dbarr.findIndex(element => element.CD == this.teamItf.dir_cd);
                if(dirIdx < 0){
                    console.log("Root directive" + this.teamItf.dir_cd + "not found!!");
                    break;
                }
                this.dirCpn = dbarr[dirIdx];

                deptArr = this.dirCpn.DEPT;
                deptIdx = deptArr.findIndex(element => element.CD == this.teamItf.dept_cd);
                if(deptIdx < 0){
                    console.log("Root department" + this.teamItf.dept_cd + "not found!!");
                    break;
                }                
                this.deptCpn = deptArr[deptIdx];

                if(this.deptCpn.TEAM){
                    this.deptCpn.TEAM.push(this.teamCpn);
                }else{
                    this.deptCpn.TEAM = [this.teamCpn];
                }

                deptArr[deptIdx] = this.deptCpn;
                this.dirCpn.DEPT = deptArr;
                
                dbarr[dirIdx] = this.dirCpn;
                this.matrixdbstr = JSON.stringify(dbarr);

                break;
            
            case "res":
                this.resItf = itfData;
                this.resCpn = {
                    ID: this.resItf.res_id,
                    NAME: this.resItf.res_name,
                    DESIGNATION: this.resItf.res_designation,
                    ROLE: this.resItf.res_role,
                    STT_DT: this.resItf.res_stt_dt,
                    SKILLSET: [],
                    SKILL: []
                };

                dirIdx = dbarr.findIndex(element => element.CD == this.resItf.dir_cd);
                if(dirIdx < 0){
                    console.log("Root directive" + this.resItf.dir_cd + "not found!!");
                    break;
                }
                this.dirCpn = dbarr[dirIdx];

                deptArr = this.dirCpn.DEPT;
                deptIdx = deptArr.findIndex(element => element.CD == this.resItf.dept_cd);
                if(deptIdx < 0){
                    console.log("Root department" + this.resItf.dept_cd + "not found!!");
                    break;
                }                
                this.deptCpn = deptArr[deptIdx];

                teamArr = this.deptCpn.TEAM;
                teamIdx = teamArr.findIndex(element => element.CD == this.resItf.team_cd);
                if(teamIdx < 0){
                    console.log("Root team" + this.resItf.team_cd + "not found!!");
                    break;
                }                
                this.teamCpn = teamArr[deptIdx];

                if(this.teamCpn.RESOURCE){
                    this.teamCpn.RESOURCE.push(this.resCpn);
                }else{
                    this.teamCpn.RESOURCE = [this.resCpn];
                }

                teamArr[teamIdx] = this.teamCpn;
                this.deptCpn.TEAM = teamArr;

                deptArr[deptIdx] = this.deptCpn;
                this.dirCpn.DEPT = deptArr;
                
                dbarr[dirIdx] = this.dirCpn;
                this.matrixdbstr = JSON.stringify(dbarr);

            default:
                console.log("Component name invalid!!" + cpn);

        }
    }


    update(cpn: string, itfData){

        let dbarr = JSON.parse(this.matrixdbstr);

        switch(cpn){
            case "dir":

                this.dirItf = itfData;
                this.dirCpn = {
                    CD: this.dirItf.dir_cd,
                    NAME: this.dirItf.dir_name,
                    DESC: this.dirItf.dir_desc
                };

                dbarr = JSON.parse(this.matrixdbstr);

                let idx = dbarr.findIndex( (element) => element.cd == this.dirCpn.CD);

                if(idx < 0){
                    if(this.dirCpn.NAME >= " "){}else{
                        this.dirCpn.NAME = dbarr[idx].nm;
                    }
                    if(this.dirCpn.DESC >= " "){}else{
                        this.dirCpn.DESC = dbarr[idx].desc;
                    }
                    this.dirCpn.DEPT = dbarr[idx].dept
                    dbarr[idx] = this.dirCpn;
                    this.matrixdbstr = JSON.stringify(dbarr);
                }
                else{
                    console.log("directive not found for update");
                }

                break;

            default:
                console.log("Component name invalid!!");
        }

    }

    select(cpn: string, itfData){
        
        let dbarr: [dirComponent];
        let deptArr: [deptComponent];
        let teamArr: [teamComponent];
        let resArr: [resourceComponent];

        let dirIdx;
        let deptIdx;
        let teamIdx;
        let resIdx;

        dbarr = JSON.parse(this.matrixdbstr);

        switch(cpn){
            case "dir":
            
                this.dirItf = itfData;

                dirIdx = dbarr.findIndex( (element) => element.CD == this.dirItf.dir_cd);
                this.dirCpn = dbarr[dirIdx];

                if(dirIdx >= 0){
                    return dbarr[dirIdx];
                    
                }

                console.log("directive not found for select");
                break;

            case "dept":
            
                this.deptItf = itfData;

                dirIdx = dbarr.findIndex( (element) => element.CD == this.deptItf.dir_cd);
                this.dirCpn = dbarr[dirIdx];
                
                deptArr = this.dirCpn.DEPT;
                deptIdx = deptArr.findIndex( (element) => element.CD == this.deptItf.dept_cd);
                this.deptCpn = deptArr[deptIdx];

                if(deptIdx >= 0){
                    return this.deptCpn;
                }
                
                console.log("directive not found for select");
                break;

            case "team":
            
                this.teamItf = itfData;

                dirIdx = dbarr.findIndex( (element) => element.CD == this.teamItf.dir_cd);
                this.dirCpn = dbarr[dirIdx];
                
                deptArr = this.dirCpn.DEPT;
                deptIdx = deptArr.findIndex( (element) => element.CD == this.teamItf.dept_cd);
                this.deptCpn = deptArr[deptIdx];

                teamArr = this.deptCpn.TEAM;
                teamIdx = teamArr.findIndex( (element) => element.CD == this.teamItf.team_cd );
                this.teamCpn = teamArr[teamIdx];

                if(teamIdx >= 0){
                    return this.teamCpn;
                }
                
                console.log("directive not found for select");
                break;
                    
            case "res":
            
                this.resItf = itfData;

                dirIdx = dbarr.findIndex( (element) => element.CD == this.resItf.dir_cd);
                this.dirCpn = dbarr[dirIdx];
                
                deptArr = this.dirCpn.DEPT;
                deptIdx = deptArr.findIndex( (element) => element.CD == this.resItf.dept_cd);
                this.deptCpn = deptArr[deptIdx];

                teamArr = this.deptCpn.TEAM;
                teamIdx = teamArr.findIndex( (element) => element.CD == this.resItf.team_cd );
                this.teamCpn = teamArr[teamIdx];

                teamArr = this.deptCpn.TEAM;
                teamIdx = teamArr.findIndex( (element) => element.CD == this.resItf.team_cd );
                this.teamCpn = teamArr[teamIdx];

                if(dirIdx >= 0){
                    return this.teamCpn;
                }

                console.log("directive not found for select");
                break;
                    
            default:
                console.log("Component name invalid!!");
        }

    }

    delete(cpn: string, itfData){
              
        let dbarr = JSON.parse(this.matrixdbstr);

        switch(cpn){
            case "dir":
            
                this.dirItf = itfData;
                this.dirCpn = {
                    CD: this.dirItf.dir_cd,
                    NAME: this.dirItf.dir_name,
                    DESC: this.dirItf.dir_desc
                };

                dbarr = JSON.parse(this.matrixdbstr);

                let idx = dbarr.findIndex( (element) => element.cd == this.dirCpn.CD);

                if(idx >= 0){
                    dbarr.splice(idx, 1);
                    this.matrixdbstr = JSON.stringify(dbarr);
                }

                console.log("directive not found for update");
                break;

            default:
                console.log("Component name invalid!!");
                
        }

    }

}

export var obj1 = new dbrequest();