import { Injectable } from "@angular/core";
import { Employee } from '../models/employee.model';
import { VirtualTimeScheduler } from 'rxjs';

@Injectable()

export class EmployeeService{
    private listEmployees: Employee[] =[{
        id: 1,
        name: 'Thanu',
        gender: 'Male',
        contactPreference: 'Email',
        email: 'thanu41290@gmail.com',
        dateOfBirth: new Date('12/04/1990'),
        department: '3',
        isActive: true,
        photoPath: 'assets/images/logo_kbc.jpg'
      },
      {
        id: 2,
        name: 'Thamizh',
        gender: 'Male',
        contactPreference: 'Email',
        email: 'thamizh41290@gmail.com',
        dateOfBirth: new Date('12/06/1990'),
        department: '3',
        isActive: true,
        photoPath: 'assets/images/logo_kbc.jpg'
      },
      {
        id: 3,
        name: 'Deepak',
        gender: 'Male',
        contactPreference: 'Email',
        email: 'Deepak41290@gmail.com',
        dateOfBirth: new Date('12/08/1990'),
        department: '3',
        isActive: true,
        photoPath: 'assets/images/logo_kbc.jpg'
      }];

      getEmployees(): Employee[] {
            return this.listEmployees;
      }
      save(employee: Employee){
            this.listEmployees.push(employee);
      }

}