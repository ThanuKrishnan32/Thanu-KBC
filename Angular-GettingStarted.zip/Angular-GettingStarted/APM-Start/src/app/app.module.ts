import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { SkillsComponent} from './skills/skills.component';
import { StarComponent } from './shared/star.componen';
import { from } from 'rxjs';

@NgModule({
  declarations: [
    AppComponent, SkillsComponent, StarComponent
  ],
  imports: [
    BrowserModule, FormsModule,HttpClientModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
