import { Component, OnInit } from '@angular/core';
import { IProduct } from './product';
import { IpcNetConnectOpts } from 'net';
import { ProductService } from 'src/api/products/product.service';

@Component({
  selector: 'sm-galore',
  templateUrl:'./skills.component.html',
  styleUrls: ['./skills.component.css']
})
export class SkillsComponent implements OnInit {
    
  pageTitle: string = 'Skill Set';
  imageWidth: number = 50;
  showImage: boolean = false;
  imageMargin: number = 2;
  errorMessage: string;
  _listFilter: string ;
  get listFilter() : string {
   return this._listFilter;
  }
  set listFilter(value:string){
      this._listFilter = value;
      this.filteredProducts= this.listFilter ? this.performFilter(this.listFilter) : this.skills;
  }
  filteredProducts : IProduct[];
  skills: IProduct[] =[
];
constructor( private productService: ProductService) {
    
}
toggleImage(): void {
    this.showImage = !this.showImage;
}
ngOnInit(): void {
    this.productService.getProducts().subscribe({
      next: skills => { this.skills = skills
        this.filteredProducts =this.skills},
      error: err => {this.errorMessage = err}
    });
    
}
performFilter(filterBy: string): IProduct[] {
    filterBy = filterBy.toLocaleLowerCase();
    return this.skills.filter((product : IProduct) =>
          product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);

}
}