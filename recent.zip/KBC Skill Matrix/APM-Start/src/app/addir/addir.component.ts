import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup,FormControl,FormBuilder } from '@angular/forms';

@Component({
  selector: 'addir',
  templateUrl: './addir.component.html',
  styleUrls: ['./addir.component.css']
})
export class addirComponent implements OnInit {

  addirForm: FormGroup;

  constructor(private router: Router, private fb: FormBuilder) { }

  ngOnInit() {
    this.addirForm = this.fb.group({
      DirName: '',
      DeptName: '',
      TeamName: '',
      
    }
    )
    this.addirForm.valueChanges.subscribe(console.log)
  }

  onBack(): void {
  this.router.navigate (['/directorate']);
}


 /*save() {
    console.log(this.addirForm);
    console.log('Saved: ' + JSON.stringify(this.addirForm));
  }*/

    
}
