import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { SkillsComponent} from './skills/skills.component';
import { StarComponent } from './shared/star.componen';
import { from } from 'rxjs';
import { SkillsDetailComponent } from './skills/skills-detail.component';
import { WelcomeComponent } from './home/welcome.component';
import { RouterModule } from '@angular/router';
import { DirectorateComponent } from './directorate/directorate.component';
import { DirectorateService } from './directorate/directorate.service';
import { addirComponent } from './addir/addir.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatInputModule} from '@angular/material/input';
import { MatFormFieldModule} from '@angular/material';
import { MatSelectModule} from '@angular/material/select';
import { MatButtonModule} from '@angular/material/button';
import { MatCheckboxModule} from '@angular/material/checkbox';
import { MatChipsModule} from '@angular/material/chips';



@NgModule({
  declarations: [
    AppComponent, SkillsComponent, StarComponent, SkillsDetailComponent,WelcomeComponent, DirectorateComponent,addirComponent
  ],
  imports: [
    BrowserModule, FormsModule,HttpClientModule,ReactiveFormsModule,BrowserAnimationsModule,MatInputModule,MatFormFieldModule,
    MatSelectModule,MatButtonModule,MatCheckboxModule,MatChipsModule,
    RouterModule.forRoot([
      { path: 'directorate', component:DirectorateComponent},
      { path: 'skills', component:SkillsComponent},
      { path: 'skills/:id', component:SkillsDetailComponent},
      { path: 'Welcome', component:WelcomeComponent},
      { path: 'addir', component:addirComponent},
      { path: '', redirectTo: 'Welcome', pathMatch: 'full' },
      { path: '**', redirectTo: 'Welcome', pathMatch: 'full'} /*can be used for 404*/

    ])
  ],
  bootstrap: [AppComponent],
  providers: [DirectorateService]
})
export class AppModule { }
